/********************************************************************
* TP1 - CUNHA CARNEIRO Luana Patrícia
 ********************************************************************/

#include "memory.h"

using namespace std;

tlm::tlm_response_status memory::write(const ensitlm::addr_t &a, //adress
				       const ensitlm::data_t &d) { // data
	if (a/4 < memory::mem_size){
		memory::storage[a/4] = d;
		cout << memory::name() << " Write adress: " << a << " \n data: " << d << endl;
		//<< " = " << memory::storage[a/4] 
	return tlm::TLM_OK_RESPONSE;	
	}else{ 
		SC_REPORT_ERROR("TLM", "Write out of bound");
        abort();
	}
	
}

tlm::tlm_response_status memory::read (const ensitlm::addr_t &a,
				       		 ensitlm::data_t &d) {
	if(a/4 < memory::mem_size){
		d = memory::storage[a/4];
		cout << memory::name() << " Read: " << a << " data: "<< d << endl;
		return tlm::TLM_OK_RESPONSE;
	}else{ 
		SC_REPORT_ERROR("TLM", "Read out of bound");
        abort();
	}
	
}

	memory::memory(sc_core::sc_module_name name, unsigned int size) /* construtor*/
	: sc_core::sc_module(name),mem_size(size) { 
		memory::storage = (ensitlm::data_t*) malloc(size * sizeof(ensitlm::data_t)); }

	memory::~memory(){ /* destrutor*/
		delete(memory::storage);
	}